# WordPress Functions List (From V0 to V4.8.1)

This is a list of all WordPress functions in version 4.8.1 along with the data of when they were first introduced and if they are deprecated or not

This repository will be updated when a new version of WordPress will be released. 

Feel free to use this json file for all your WordPress function related works. Enjoy!